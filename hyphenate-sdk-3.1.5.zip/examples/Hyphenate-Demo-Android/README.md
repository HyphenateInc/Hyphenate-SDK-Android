# sdkdemoapp3.0_android
--------
## Description
Hyphenate Mobile Instant Messaging Demo app. This messaging app demonstrates how to use the Hyphenate Mobile Instant Messaging (MIM) platform, SDK and backend API to build and deploy a mobile app with integrated chat features. Developers can leverage this app as a reference example to build their own apps integrated with the Hyphenate MIM service.
## Dependencies
EaseUI is a UI library based on hyphenate SDK, encapsulates the IM function of commonly used components, fragments, and so on. [https://github.com/HyphenateInc/Hyphenate-EaseUI-Android](https://github.com/HyphenateInc/Hyphenate-EaseUI-Android)