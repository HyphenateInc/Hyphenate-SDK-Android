# easeui_android
####EaseUI encapsulate common IM features, Chat view, chat list view, contact list view, etc, to faciliate the integration process with hyphenate SDK.

####[Initialize easeui_android](http://docs.hyphenate.io/im/androidclientintegration/easeuiuseguide)



