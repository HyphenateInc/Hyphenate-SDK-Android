var searchData=
[
  ['hanzitopinyin',['HanziToPinyin',['../classcom_1_1hyphenate_1_1util_1_1_hanzi_to_pinyin.html',1,'com::hyphenate::util']]],
  ['hasnetwork',['hasNetwork',['../classcom_1_1hyphenate_1_1util_1_1_net_utils.html#aad376727d38cbaae5cd3c9ff25b6e208',1,'com::hyphenate::util::NetUtils']]],
  ['hasreservedlogouttime',['hasReservedLogoutTime',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_preference_utils.html#aa53c31d04ed5ada56c8e403b8bc51e69',1,'com::hyphenate::chat::EMPreferenceUtils']]]
];
