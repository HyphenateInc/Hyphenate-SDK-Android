var searchData=
[
  ['general_5ferror',['GENERAL_ERROR',['../classcom_1_1hyphenate_1_1_e_m_error.html#aa0588007ca25fab81e635625f01639bc',1,'com::hyphenate::EMError']]],
  ['group_5falready_5fjoined',['GROUP_ALREADY_JOINED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a4df77f4928f2cb365e7089a52e8cda2d',1,'com::hyphenate::EMError']]],
  ['group_5finvalid_5fid',['GROUP_INVALID_ID',['../classcom_1_1hyphenate_1_1_e_m_error.html#af4f51c046ca4a82ea41d9ee3e4ab5832',1,'com::hyphenate::EMError']]],
  ['group_5fmembers_5ffull',['GROUP_MEMBERS_FULL',['../classcom_1_1hyphenate_1_1_e_m_error.html#acd4fdf197c83dbb8d4ad0fffbc2258c6',1,'com::hyphenate::EMError']]],
  ['group_5fnot_5fexist',['GROUP_NOT_EXIST',['../classcom_1_1hyphenate_1_1_e_m_error.html#afeda85f3d61e17baf12be942a5d58e07',1,'com::hyphenate::EMError']]],
  ['group_5fnot_5fjoined',['GROUP_NOT_JOINED',['../classcom_1_1hyphenate_1_1_e_m_error.html#ac1eb45bfd243d809ea25c60b9277249f',1,'com::hyphenate::EMError']]],
  ['group_5fpermission_5fdenied',['GROUP_PERMISSION_DENIED',['../classcom_1_1hyphenate_1_1_e_m_error.html#a5fd34106c7e9b063430743fd0f2ce7b7',1,'com::hyphenate::EMError']]],
  ['groupchat',['GroupChat',['../enumcom_1_1hyphenate_1_1chat_1_1_e_m_message_1_1_chat_type.html#aa83280ce79df6f5aa49f7a5223498cad',1,'com::hyphenate::chat::EMMessage::ChatType']]]
];
