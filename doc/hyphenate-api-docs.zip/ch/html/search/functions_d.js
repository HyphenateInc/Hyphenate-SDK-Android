var searchData=
[
  ['pausevideotransfer',['pauseVideoTransfer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#a19e6305d014c0cc0f19e94c40cee7c63',1,'com::hyphenate::chat::EMCallManager']]],
  ['pausevoicetransfer',['pauseVoiceTransfer',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_call_manager.html#a13470d6e6725c31285f97b4ed0b7217e',1,'com::hyphenate::chat::EMCallManager']]],
  ['px2dip',['px2dip',['../classcom_1_1hyphenate_1_1util_1_1_density_util.html#a7c27031b0c4b403031794d4dcb61be69',1,'com::hyphenate::util::DensityUtil']]],
  ['px2sp',['px2sp',['../classcom_1_1hyphenate_1_1util_1_1_density_util.html#a3cd424e112d001682bfb62cd6b3c755f',1,'com::hyphenate::util::DensityUtil']]]
];
