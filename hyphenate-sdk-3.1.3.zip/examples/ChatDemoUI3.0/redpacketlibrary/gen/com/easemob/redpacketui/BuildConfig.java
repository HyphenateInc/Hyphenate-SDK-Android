/** Automatically generated file. DO NOT MODIFY */
package com.easemob.redpacketui;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}